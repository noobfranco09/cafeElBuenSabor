<?php require_once $_SERVER["DOCUMENT_ROOT"] . '/cafeelbuensabor/functions/rutas.php'; ?>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title> No Encontrada</title>
  <link rel="stylesheet" href= "<?php echo BASE_URL.'assets/css/404.css' ?>">
</head>
<body>
  <div class="container">
    <h1>Atencion</h1>
    <h2>Este codigo qr esta caducado o no existe</h2>
    <p>Lo sentimos.</p>
    <a  class="button">Solicitele nuevamente el codigo QR a su mesero</a>
  </div>
</body>
</html>
