<?php
if (!defined('BASE_URL')) {
    define('BASE_URL', '/cafeelbuensabor'.'/');
}
if (!defined('BASE_PATH')) {
    define('BASE_PATH', $_SERVER['DOCUMENT_ROOT'] . '/cafeelbuensabor'.'/'); 
}
?>